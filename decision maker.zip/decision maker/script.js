var inputDiv=document.querySelector('.input-div');
const DivLength= inputDiv.children.length;
const randomDivChild=Math.floor(Math.random()* DivLength);
function decide()
{
	alert(inputDiv.children[randomDivChild].value);

}

   function entitySub()
  {
    inputDiv.removeChild(inputDiv.lastElementChild)
  }
  function entityPlus() {
  	 const input=document.createElement('input');
  	 inputDiv.appendChild(input)

  }